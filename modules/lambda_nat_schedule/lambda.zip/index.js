// Lambda実行関数 NatGatewayを削除するNode.js
const AWS = require('aws-sdk');
const ec2 = new AWS.EC2();

exports.handler = async (event) => {
  const action = event.action;  // "start" or "stop"
  const natGatewayId = process.env.NAT_GATEWAY_ID;

  // NAT_GATEWAY_IDがない場合エラーを返す
  if (!natGatewayId) {
    throw new Error("NAT_GATEWAY_ID is not set");
  }

  try {
    if (action === "stop") {
      await ec2.deleteNatGateway({ NatGatewayId: natGatewayId }).promise();
      console.log(`Nat Gateway ${natGatewayId} stopped`);
    } else if (action === "start") {
      const allocationId = process.env.ALLOCATION_ID;
      const subnetId = process.env.SUBNET_ID;

      const result = await ec2.createNatGateway({
        AllocationId: allocationId,
        SubnetId: subnetId
      }).promise();
      console.log(`NAT Gateway started: ${JSON.stringify(result)}`);
    } else {
      throw new Error(`Unknown action: ${action}`);
    }
  } catch (err) {
    console.error(err);
    throw err;
  }
};